#coding:utf-8
__author__ = 'Administrator'
import urllib
import urllib2
import cookielib

#老师帐号注册
def tchReg(teacher):
    test_data = {'username':teacher,'name':teacher,'passwd':'123456','passwd2':'123456'}
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    test_data_urlencode = urllib.urlencode(test_data)
    requrl = "http://127.0.0.1:8000/Teacher/regist/"
    req = urllib2.Request(url = requrl,data =test_data_urlencode,headers =headers)
    res_data = urllib2.urlopen(req)

#老师创建群组
def creChat(chat,teacher):
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie','tch_name='+teacher))
    data = {"name":chat,"teacher":teacher,"passwd":'123456',"advise":"无"}
    data=urllib.urlencode(data)
    request = urllib2.Request("http://127.0.0.1:8000/Teacher/crechat/", data)
    response = opener.open(request)
    return response

#发布签到
def pubAdvise(advise,chat,teacher,deltaTime,sign):
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie','tch_name='+teacher))
    data = {"title":advise,"chat":chat,"teacher":teacher,"deltaTime":deltaTime,"sign":sign}
    data=urllib.urlencode(data)
    request = urllib2.Request("http://127.0.0.1:8000/Teacher/puarri/", data)
    response = opener.open(request)
    return response

#学生注册
def stdReg(student,std_id):
    test_data = {'username':student,'name':student,'std_id':std_id,'passwd':'123456','passwd2':'123456'}
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    test_data_urlencode = urllib.urlencode(test_data)
    requrl = "http://127.0.0.1:8000/Student/regist/"
    req = urllib2.Request(url = requrl,data =test_data_urlencode,headers =headers)
    res_data = urllib2.urlopen(req)
    # res = res_data.read()

#加入群组
def stdAddChat(chat,student,teacher):
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie','std_name='+student))
    data = {"chat_name":chat,"std_name":student,"teacher":teacher}
    data=urllib.urlencode(data)
    request = urllib2.Request("http://127.0.0.1:8000/Student/addchat/", data)
    response = opener.open(request)
    return response

#学生签到
def stdArri(sign,advise,student,chat,late_reason):
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie','std_name='+student))
    data = {"user_id":sign,"name":advise,"std_name":student,'chats':chat,'late_reason':late_reason}
    data=urllib.urlencode(data)
    request = urllib2.Request("http://127.0.0.1:8000/Student/stdarri/", data)
    response = opener.open(request)
    return response

#老师发送报告
def sendEmail(teacher,chat,advise,send_email):
    opener = urllib2.build_opener()
    opener.addheaders.append(('Cookie','tch_name='+teacher))
    data = {"teacher":teacher,"chat":chat,"title":advise,'send_email':send_email}
    data=urllib.urlencode(data)
    request = urllib2.Request("http://127.0.0.1:8000/Teacher/printdelarri/", data)
    response = opener.open(request)
    return response

if __name__ == '__main__':
    teacher = 'teacher13'
    student = 'studentwfewthe26e'
    chat = 'chat13'
    advise = 'advise13'
    deltaTime = 6
    late_reason = "没有"
    send_email = '1018589158@qq.com'
    sign = '123456'


    print(u"教师注册")
    tchReg(teacher)
    print(u"学生注册")
    for i in range(2,100):
        std = student+str(i)
        stdReg(std,i)
    print(u"创建群组")
    creChat(chat,teacher)
    print(u"学生加入群组")
    for i in range(2,100):
        std = student+str(i)
        stdAddChat(chat,std,teacher)
    print(u"老师发布签到通知")
    pubAdvise(advise,chat,teacher,deltaTime,sign)
    # print(u"学生签到")
    # for i in range(2,100):
    #     std = student+str(i)
    #     stdArri(sign,advise,std,chat,late_reason)
    # print(u"发送签到")
    # sendEmail(teacher,chat,advise,send_email)

